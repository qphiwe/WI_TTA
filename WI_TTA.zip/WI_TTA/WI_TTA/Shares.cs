﻿
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading;
using excel = Microsoft.Office.Interop.Excel;

namespace WI_TTA
{
    [TestClass]
    public class Shares
    {
        IWebDriver driver;

        [TestMethod]
        public void OpenShareAcc()
        {
            excel.Application ea = new excel.Application();
            excel.Workbook ewb = ea.Workbooks.Open("C:\\Users\\w5084482\\source\\repos\\WI_TTA\\WI_TTA\\Data\\WI_Data.xlsx");
            excel._Worksheet ews = ewb.Sheets[1];
            excel.Range valRange = ews.UsedRange;
            int wi = valRange.Count;

            driver = new ChromeDriver();
            driver.Navigate().GoToUrl("https://shares.fnb.co.za/#!/");
            driver.Manage().Window.Maximize();
            Thread.Sleep(5000);

            driver.FindElement(By.XPath("//*[@id='openaccount3']")).Click();
            Thread.Sleep(500);

            for (int i = 2; i <= valRange.Count; i++)
            {
                string fName = valRange.Cells[1][i].Value2;
                string sName = valRange.Cells[2][i].Value2;
                string eMail = valRange.Cells[3][i].Value2;
                string mobile = valRange.Cells[4][i].Value2;
                string uName = valRange.Cells[5][i].Value2;
                string pWord = valRange.Cells[6][i].Value2;
                string idNum = valRange.Cells[7][i].Value2;

                driver.FindElement(By.Id("first_name")).SendKeys(fName);
                driver.FindElement(By.Id("surname")).SendKeys(sName);
                driver.FindElement(By.Id("email")).SendKeys(eMail);
                driver.FindElement(By.Id("phone")).SendKeys(mobile);
                driver.FindElement(By.Id("username")).SendKeys(uName);
                driver.FindElement(By.Id("password")).SendKeys(pWord);
                driver.FindElement(By.Id("sa_id")).SendKeys(idNum);

                driver.FindElement(By.XPath("//*[@id='content']/ui-view/div/ai-register/div/div/div/div/ai-registration-landing/div/div/div/div[2]/form/div[6]/div[3]/div[1]/div/label/div[2]")).Click();

                driver.SwitchTo().Frame(driver.FindElement(By.CssSelector("iframe[src*='recaptcha']")));
                driver.FindElement(By.XPath("/html/body/fnb-securities/div/div/div/ui-view/div/ai-register/div/div/div/div/ai-registration-landing/div/div/div/div[2]/form/div[7]/div")).Click();
                Thread.Sleep(2000);

                driver.SwitchTo().DefaultContent();
                driver.SwitchTo().Frame(driver.FindElements(By.TagName("iframe"))[1]);
                ReadOnlyCollection<IWebElement> Images = driver.FindElements(By.CssSelector("img"));
                //ChromeDriver _driver;
                //_driver = new ChromeDriver();
                //_driver.Url = "https://www.google.com/recaptcha/api2/demo";
                //Thread.Sleep(5000);

                //_driver.SwitchTo().Frame(_driver.FindElement(By.CssSelector("iframe[src*='recaptcha']")));

                //_driver.FindElement(By.ClassName("recaptcha-checkbox-checkmark")).Click();

                //Thread.Sleep(2000);

                //_driver.SwitchTo().DefaultContent();
                //_driver.SwitchTo().Frame(_driver.FindElements(By.TagName("iframe"))[1]);
                //ReadOnlyCollection<IWebElement> Images = _driver.FindElements(By.CssSelector("img"));
            }


        }
    }
}
